package com.tdsupptic2.supptic2

import android.net.Uri
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.tdsupptic2.supptic2.UserRepository.Singleton.databaserefuser
import com.tdsupptic2.supptic2.UserRepository.Singleton.publicationlistuser

class UserRepository {


    object Singleton {
        //se connecter au stockage
        //private val BUCKET_URL: String ="gs://af-style.appspot.com"
        //val storageReference = FirebaseStorage.getInstance().getReferenceFromUrl(BUCKET_URL)
        //reference fashion
        val databaserefuser = FirebaseDatabase.getInstance().getReference("Users")
        //creer une liste de recup
        val publicationlistuser = arrayListOf<UserModel>()
        //contenir le lien de l'image courente
        //var downloaduri : Uri? = null
    }

    fun updatedata2(callback: () -> Unit){
        //absorber les donnees
        databaserefuser.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                //retirons les anciennes
                publicationlistuser.clear()
                //recoltons la liste
                for (ds in snapshot.children){
                    //construire l'object image
                    val image= ds.getValue(UserModel::class.java)

                    // verifions que ces pas nul

                    if (image != null){
                        publicationlistuser.add(image)
                    }
                }
                //actionner le calback
                callback()
            }
            override fun onCancelled(error: DatabaseError) {
            }
        })
    }

    //mettre a jour un objet de la bd
    fun updatepublication(imageModel: UserModel) = databaserefuser.child(imageModel.userid).setValue(imageModel)
}