package com.tdsupptic2.supptic2

import android.net.Uri
import android.util.Log
import android.widget.Toast
import com.google.android.gms.tasks.Continuation
import com.google.android.gms.tasks.Task
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.UploadTask
import com.tdsupptic2.supptic2.PublicationRepository.Singleton.databaseref
import com.tdsupptic2.supptic2.PublicationRepository.Singleton.downloaduri
import com.tdsupptic2.supptic2.PublicationRepository.Singleton.publicationlist
import com.tdsupptic2.supptic2.PublicationRepository.Singleton.storageReference
import java.util.*

class PublicationRepository {

    object Singleton {
        //se connecter au stockage

        private val BUCKET_URL: String ="gs://supptech-78d9a.appspot.com"
        val storageReference = FirebaseStorage.getInstance().getReferenceFromUrl(BUCKET_URL)
        //reference fashion
        val databaseref = FirebaseDatabase.getInstance().getReference("publicationroui")
        //creer une liste de recup
        val publicationlist = arrayListOf<PublicationModel>()

        //contenir le lien de l'image courente
        var downloaduri : Uri? = null
    }

    fun updatedata(callback: () -> Unit){
        //absorber les donnees
        databaseref.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                //retirons les anciennes
                publicationlist.clear()
                //recoltons la liste
                for (ds in snapshot.children){
                    //construire l'object image
                    val image= ds.getValue(PublicationModel::class.java)

                    // verifions que ces pas nul

                    if (image != null){
                        publicationlist.add(image)
                    }
                }
                //actionner le calback
                callback()
            }
            override fun onCancelled(error: DatabaseError) {
            }
        })
    }

    //creer une fonction pour envoyer des fichiers sur le storage
    fun uploadimage(file: Uri, callback: () -> Unit){
        //verifier que ce fichier n'est pas nul
        if (file != null){
            val filename = UUID.randomUUID().toString() + ".jpg"
            val ref =storageReference.child(filename)
            val uploadtask = ref.putFile(file)

            //demarrer la tache d'envoi
            uploadtask.continueWithTask(Continuation<UploadTask.TaskSnapshot, Task<Uri>>{ task ->

                //s'il y'a eu un pb lors de l'envoi du fichier
                if (!task.isSuccessful){
                    task.exception?.let { throw it }
                }

                return@Continuation ref.downloadUrl

            }).addOnCompleteListener { task ->
                //verifier si tout a bien fonctionner
                if (task.isSuccessful){
                    //recuperer l'image
                    downloaduri = task.result
                    callback()
                }
            }
        }


    }

    //mettre a jour un objet de la bd
    fun updatepublication(imageModel: PublicationModel) = databaseref.child(imageModel.id).setValue(imageModel)

    //inserer un nouveau objet de la bd
    fun Insertimageobject(imageModel: PublicationModel) = databaseref.child(imageModel.id).setValue(imageModel)

    //Supprimer un objet en Bd
    fun deleteimage1(imageModel: PublicationModel) = databaseref.child(imageModel.id).removeValue()
}