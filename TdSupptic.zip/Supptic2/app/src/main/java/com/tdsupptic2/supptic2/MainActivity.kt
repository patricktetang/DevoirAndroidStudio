package com.tdsupptic2.supptic2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.principal)

        loadfragment(Fragment_home(this))

        val navview = findViewById<BottomNavigationView>(R.id.navigationview)



        navview.setOnNavigationItemSelectedListener {
            when(it.itemId){
                R.id.home -> {
                    loadfragment(Fragment_home(this))
                    return@setOnNavigationItemSelectedListener true
                }
                R.id.favorie -> {
                    loadfragment(Frag_favor(this))
                    return@setOnNavigationItemSelectedListener true
                }
                R.id.profil -> {
                    loadfragment(account_Fragments(this))
                    /*val repo2 = UserRepository()
                    repo2.updatedata2{
                        val transaction = supportFragmentManager.beginTransaction()
                        transaction.replace(R.id.framelayout, account_FragmentsShow(this))
                        transaction.addToBackStack(null)
                        transaction.commit()
                    }*/
                    return@setOnNavigationItemSelectedListener true
                }
                R.id.notif -> {
                    loadfragment(notifi(this))
                    return@setOnNavigationItemSelectedListener true
                }
                else -> false
            }
        }


    }


    private fun loadfragment(fragment: Fragment) {
        val repo = PublicationRepository()
        repo.updatedata{
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.framelayout, fragment)
            transaction.addToBackStack(null)
            transaction.commit()
        }

    }
}