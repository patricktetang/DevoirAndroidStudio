package com.tdsupptic2.supptic2

import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.view.Window
import android.widget.TextView

class assistantAcceuil(
    private val adapter: account_Fragments,
): Dialog(adapter.requireContext()) {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.assistantacceuil)

        val ok = findViewById<TextView>(R.id.Ok)
        val postauto = findViewById<TextView>(R.id.postauto)

        ok.setOnClickListener {
            dismiss()
            voirdonne(adapter).show()
        }
        postauto.setOnClickListener {
            dismiss()
            adapter.startActivity(Intent(context,MainActivity::class.java))
        }



    }

}