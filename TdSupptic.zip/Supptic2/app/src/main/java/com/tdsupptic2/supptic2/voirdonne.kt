package com.tdsupptic2.supptic2

import android.app.Dialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Window
import android.widget.ImageView
import android.widget.TextView
import com.tdsupptic2.supptic2.account_Fragments.singleton.email123
import com.tdsupptic2.supptic2.account_Fragments.singleton.pass123
import com.tdsupptic2.supptic2.account_Fragments.singleton.pseudo123

class voirdonne(
    private val adapter: account_Fragments,
): Dialog(adapter.requireContext()) {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.voirdonnee)

        val ok = findViewById<TextView>(R.id.oli)
        val a = findViewById<TextView>(R.id.a)
        val b = findViewById<TextView>(R.id.b)
        val c = findViewById<TextView>(R.id.c)

        a.setText(pseudo123)
        b.setText(email123)
        c.setText(pass123)

        ok.setOnClickListener {
            dismiss()
            adapter.startActivity(Intent(context,MainActivity::class.java))
        }




    }

}