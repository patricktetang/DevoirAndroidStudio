package com.tdsupptic2.supptic2

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class PublicationAdapter(
    val context: MainActivity,
    private val publicationlist: List<PublicationModel>,
    private val layoutid: Int
) : RecyclerView.Adapter<PublicationAdapter.viewholder>() {

    class viewholder(view: View) : RecyclerView.ViewHolder(view){
        val name = view.findViewById<TextView>(R.id.nompub)
        val heure = view.findViewById<TextView>(R.id.heurpub)
        val extimate: TextView? =view.findViewById(R.id.templecture)
        val text: TextView? = view.findViewById(R.id.affiche)
        val profilimage = view.findViewById<ImageView>(R.id.imdepub)
        val publicationimage = view.findViewById<ImageView>(R.id.iamy)
        val favorie = view.findViewById<ImageView>(R.id.savepub)
        val partager = view.findViewById<TextView>(R.id.partager)
        val troispoin = view.findViewById<ImageView>(R.id.troispoint)
        val lireplus = view.findViewById<TextView>(R.id.lireplus)
        //val lind = view.findViewById<LinearLayout>(R.id.lind)*/


    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PublicationAdapter.viewholder {
        val view = LayoutInflater
            .from(parent.context)
            .inflate(layoutid, parent,false)

        return viewholder(view)
    }

    override fun onBindViewHolder(holder: PublicationAdapter.viewholder, position: Int) {
        //recup les infos

        val repo = PublicationRepository()
        val currentpublication = publicationlist[position]
        val text:String = currentpublication.publicationimage
        Glide.with(context).load(Uri.parse(currentpublication.profilpic)).into(holder.profilimage)
        Glide.with(context).load(Uri.parse(currentpublication.publicationimage)).into(holder.publicationimage)
        if (currentpublication.publicationimage.equals("null")){
            holder.publicationimage.visibility = View.GONE
        }
        else{
            holder.publicationimage.visibility = View.VISIBLE
        }
        holder.text?.text = currentpublication.textpic
        holder.name.text = currentpublication.namepic
        holder.heure.text = currentpublication.heurepic
        holder.extimate?.text = currentpublication.extimatepic


        holder.favorie.setOnClickListener {
            currentpublication.favor = !currentpublication.favor
            if (currentpublication.favor == true){
                Toast.makeText(context,"liked",Toast.LENGTH_SHORT).show()
            }
            if (currentpublication.favor == false){
                Toast.makeText(context,"unliked",Toast.LENGTH_SHORT).show()
            }
            repo.updatepublication(currentpublication)

        }

        if (currentpublication.favor){
            holder.favorie.setImageResource(R.drawable.ic_fav)
        }else{
            holder.favorie.setImageResource(R.drawable.ic_favorieun)
        }
        /*holder.lireplus.setOnClickListener {
            val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT)
            holder.text?.layoutParams = params
            holder.lireplus.visibility = View.GONE
        }*/


        holder.partager.setOnClickListener {
            share(text)
        }


        //val lire = holder.troispoin
        //ouvrirpopup(lire,text)
    }

    /*private fun ouvrirpopup(lire: ImageView?, text: String) {

        val popupmenu = PopupMenu(context, lire)
        popupmenu.inflate(R.menu.donloadmenu)
        popupmenu.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.share -> {
                    share(text)
                    true
                }
                R.id.download -> {
                    download(text)
                    Toast.makeText(context,"votre telechargement est terminer", Toast.LENGTH_LONG).show()
                    true
                }
                R.id.download -> {
                    val emailIntent = Intent(Intent.ACTION_SENDTO,
                        Uri.fromParts("mailto","afrostyle95@gmail.com", null))
                    context.startActivity(Intent.createChooser(emailIntent,"Send email..."))
                    Toast.makeText(context,"Email Opening......", Toast.LENGTH_LONG).show()
                    true
                }
                else -> true
            }
        }
        lire?.setOnClickListener {

            try {
                val popup = PopupMenu::class.java.getDeclaredField("mPopup")
                popup.isAccessible = true
                val menu = popup.get(popupmenu)
                menu.javaClass
                    .getDeclaredMethod("setForceShowIcon", Boolean::class.java)
                    .invoke(menu, true)
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                popupmenu.show()
            }
            true
        }
    }*/

    private fun download(text: String) {
        val request = DownloadManager.Request(Uri.parse(text))
            .setTitle("file")
            .setDescription("Downloading......")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setAllowedOverMetered(true)
        val ds = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        ds.enqueue(request)
        Toast.makeText(context,"votre telechargement est terminer", Toast.LENGTH_LONG).show()
    }

    private fun share(text: String) {
        //val text:String =currentImage.imageUrl
        val intent = Intent(Intent.ACTION_SEND)
        intent.type="text/plain"
        intent.putExtra(
            Intent.EXTRA_TEXT,
            "have you seen this our school publication?? : "+text)
        val chooser = Intent.createChooser(intent, "share using......")
        context.startActivity(chooser)
    }

    override fun getItemCount(): Int {
        return publicationlist.size
    }
}

