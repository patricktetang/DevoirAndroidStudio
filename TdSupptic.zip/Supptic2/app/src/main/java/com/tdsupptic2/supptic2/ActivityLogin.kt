package com.tdsupptic2.supptic2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.util.Patterns
import android.view.View
import android.widget.*
import com.google.firebase.auth.FirebaseAuth

class ActivityLogin : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.loginacti)

        val Email = findViewById<EditText>(R.id.email)
        val password = findViewById<EditText>(R.id.pass)
        val googlebuton = findViewById<Button>(R.id.bouton2)
        val creercompte = findViewById<TextView>(R.id.connectbut)
        val oublier = findViewById<TextView>(R.id.oublier)
        val seconnecterbutactivity = findViewById<Button>(R.id.butt1)


        googlebuton.setOnClickListener {

        }

        oublier.setOnClickListener {

        }

        creercompte.setOnClickListener {
            val intent = Intent(this, ActivityInscriptions::class.java)
            startActivity(intent)
        }

        seconnecterbutactivity.setOnClickListener {
            if (Email.text.toString().length < 5) {
                Email.error = "inferieur a 5 caracteres"
                Toast.makeText(
                    this,
                    "votre Email ne doit pas etre inferieur a 5 caracteres.",
                    Toast.LENGTH_LONG
                ).show()
            } else if (!Patterns.EMAIL_ADDRESS.matcher(Email.text.toString()).matches()) {
                Email.error = "invalid email format"
            } else if (password.text.toString().length < 8) {
                password.error = "inferieur a 8 caracteres"
                Toast.makeText(
                    this,
                    "votre password ne doit pas etre inferieur a 8 caracteres.",
                    Toast.LENGTH_LONG
                ).show()
            } else if (TextUtils.isEmpty(Email.toString())) {
                //password isn't entered
                Email.error = "please enter name"
            } else if (TextUtils.isEmpty(password.toString())) {
                //password isn't entered
                password.error = "please enter name"
            } else {
                Toast.makeText(this, "tout est ok", Toast.LENGTH_LONG).show()
                auth = FirebaseAuth.getInstance()
                val nom1: String = Email.text.toString()
                val password1: String = password.text.toString()
                val currentUser = auth.currentUser
                auth.signInWithEmailAndPassword(nom1, password1)
                    .addOnCompleteListener(this) { task ->
                        if (task.isSuccessful) {
                            val firebaseUser =auth.currentUser
                            val email =firebaseUser!!.email
                            if (firebaseUser.isEmailVerified){
                                Toast.makeText(this, "LoggedIn as $email",Toast.LENGTH_SHORT).show()
                                //open profile
                                startActivity(Intent(this,MainActivity::class.java))
                                finish()
                            }
                            else{
                                Toast.makeText(this,"your address is not verified.please verify your Email",Toast.LENGTH_LONG).show()
                            }

                            // updateUI(user)
                        } else {
                            // If sign in fails, display a message to the user.
                            //Log.w(TAG, "signInWithEmail:failure", task.exception)
                            Toast.makeText(baseContext, "Echec de connexion.",
                                Toast.LENGTH_SHORT).show()
                            //updateUI(null)
                        }
                    }

            }
        }

        auth = FirebaseAuth.getInstance()
        val firebaseUser = auth.currentUser
        val email =firebaseUser?.email
        if (email != null) {
            if (firebaseUser.isEmailVerified) {
                //user is already logged in
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            }
            else{
                Toast.makeText(this,"votre addresse email n'est pas verifier,verifier votre Email  pour continuer",Toast.LENGTH_LONG).show()
            }
        }else{

        }
    }
}