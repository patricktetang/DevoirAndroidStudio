package com.tdsupptic2.supptic2

import android.content.Context
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class NotifAdapt(
    val context: MainActivity,
    private val publicationlist: List<PublicationModel>,
    private val layoutid: Int
) : RecyclerView.Adapter<NotifAdapt.viewholder>() {

    class viewholder(view: View) : RecyclerView.ViewHolder(view){
        val name = view.findViewById<TextView>(R.id.namenotif)
        val minutes = view.findViewById<TextView>(R.id.minutesnotif)

    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NotifAdapt.viewholder {
        val view = LayoutInflater
            .from(parent.context)
            .inflate(layoutid, parent,false)

        return viewholder(view)
    }

    override fun onBindViewHolder(holder: NotifAdapt.viewholder, position: Int) {
        val currentpublication = publicationlist[position]

        holder.name.text = currentpublication.namepic
        holder.minutes.text = currentpublication.extimatepic
    }

    override fun getItemCount(): Int {
        return publicationlist.size
    }
}