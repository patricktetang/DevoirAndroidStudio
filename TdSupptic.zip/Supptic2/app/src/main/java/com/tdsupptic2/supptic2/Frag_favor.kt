package com.tdsupptic2.supptic2

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.tdsupptic2.supptic2.PublicationRepository.Singleton.publicationlist

class Frag_favor(
 private val context : MainActivity
) : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view =inflater?.inflate(R.layout.activity_main, container, false)

        //recuperer le recycler view
        val publicationrecyclerview = view.findViewById<RecyclerView>(R.id.android_recyclerview)
        //val publicationlist =arrayListOf<PublicationModel>()
        publicationrecyclerview.adapter = PublicationAdapter(context, publicationlist.filter { it.favor }, R.layout.publish)



        return view
    }
}