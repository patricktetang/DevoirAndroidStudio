package com.tdsupptic2.supptic2

import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.util.Patterns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.tdsupptic2.supptic2.PublicationRepository.Singleton.publicationlist
import com.tdsupptic2.supptic2.account_Fragments.singleton.email123
import com.tdsupptic2.supptic2.account_Fragments.singleton.pass123
import com.tdsupptic2.supptic2.account_Fragments.singleton.pseudo123

class account_Fragments(
   private val context : MainActivity,
) : Fragment() {

    object singleton {
        var pseudo123 : String = ""
        var email123 : String = ""
        var pass123 : String = ""
    }
    private lateinit var auth: FirebaseAuth
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view =inflater?.inflate(R.layout.profiluser, container, false)


        val newpseudo = view.findViewById<EditText>(R.id.newpseudo)
        val newemail = view.findViewById<EditText>(R.id.newemail)
        val newpass = view.findViewById<EditText>(R.id.newpassword)
        val newconfirmpass = view.findViewById<EditText>(R.id.newconfirmpass)
        val newbut = view.findViewById<Button>(R.id.newbutsend)


        newbut.setOnClickListener {
            validatedata(newpseudo,newemail,newpass,newconfirmpass)
        }


        return view
    }

    private fun validatedata(newpseudo: EditText?, newemail: EditText?, newpass: EditText?, newconfirmpass: EditText?) {

        val an = newpseudo?.text.toString().lowercase()
        if (TextUtils.isEmpty(newpseudo?.text.toString())){
            newpseudo?.error ="please enter name"
        }
        if (newpseudo?.text.toString().length < 5){
            newpseudo?.error ="Inferieur a 5."
        }
        if (an.equals("anonyme") ||an.equals("anonymous") || an.equals("anonyme ") ||an.equals("anonymous ") || an.equals("anonymes") ||an.equals("anonymes ")){
            newpseudo?.error ="Ce nom n'est pas autoriser."
        }
        else if(TextUtils.isEmpty(newpass?.text.toString())){
            newpass?.error ="please enter password"
        }
        else if(!Patterns.EMAIL_ADDRESS.matcher(newemail?.text.toString()).matches()){
            newemail?.error ="invalid email format"
        }
        else if(TextUtils.isEmpty(newemail?.text.toString())){
            newemail?.error ="please enter Email."
        }
        else if(TextUtils.isEmpty(newpass?.text.toString())){
            newpass?.error ="please enter password."
        }
        else if(newpass?.text.toString().length < 8){
            newpass?.error ="too short"
        }
        else if (TextUtils.isEmpty(newconfirmpass?.text.toString())){
            newconfirmpass?.error ="please enter password."
        }
        else if(newconfirmpass?.text.toString().length < 8){
            newconfirmpass?.error ="too short"
        }
        else if(!newpass?.text.toString().equals(newconfirmpass?.text.toString())){
            newconfirmpass?.error ="No Matched"
            newpass?.error ="No Matched"
        }
        else{
           pseudo123 = newpseudo?.text.toString()
            email123 = newemail?.text.toString()
            pass123 = newpass?.text.toString()
            assistantAcceuil(this).show()
            Toast.makeText(getContext(), "vos donnees sont mis a jour avec succes", Toast.LENGTH_SHORT).show()
        }
    }

}