package com.tdsupptic2.supptic2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class ActivityInscriptions : AppCompatActivity() {
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var databaseReference: DatabaseReference
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_compte)

        val connectbut = findViewById<Button>(R.id.buttvalidate)



        connectbut.setOnClickListener {
            val username = findViewById<EditText>(R.id.text1nom)
            val useremail = findViewById<EditText>(R.id.text2email)
            val userpasword = findViewById<EditText>(R.id.text3pass)
            val an = username.text.toString().lowercase()
            val userconfirmpasword = findViewById<EditText>(R.id.text4confirmpass)
            if (TextUtils.isEmpty(username.text.toString())){
                username.error ="please enter name"
            }
            if (username.text.toString().length < 5){
                username.error ="Inferieur a 5."
            }
            if (an.equals("anonyme") ||an.equals("anonymous") || an.equals("anonyme ") ||an.equals("anonymous ") || an.equals("anonymes") ||an.equals("anonymes ")){
                username.error ="Ce nom n'est pas autoriser."
            }
            else if(TextUtils.isEmpty(userpasword.text.toString())){
                userpasword.error ="please enter password"
            }
            else if(!Patterns.EMAIL_ADDRESS.matcher(useremail.text.toString()).matches()){
                useremail.error ="invalid email format"
            }
            else if(TextUtils.isEmpty(useremail.text.toString())){
                useremail.error ="please enter Email."
            }
            else if(TextUtils.isEmpty(userpasword.text.toString())){
                userpasword.error ="please enter password."
            }
            else if(userpasword.text.toString().length < 8){
                userpasword.error ="too short"
            }
            else if (TextUtils.isEmpty(userconfirmpasword.text.toString())){
                userconfirmpasword.error ="please enter password."
            }
            else if(userconfirmpasword.text.toString().length < 8){
                userconfirmpasword.error ="too short"
            }
            else if(!userpasword.text.toString().equals(userconfirmpasword.text.toString())){
                userconfirmpasword.error ="No Matched"
                userpasword.error ="No Matched"
            }
            else{
                val nom = username.text.toString()
                val email = useremail.text.toString()
                val pasword = userpasword.text.toString()
                firebaseAuth = FirebaseAuth.getInstance()
                val profilpic : String = "https://i.pinimg.com/474x/f2/fe/5e/f2fe5e65aea64b7adb5b52dd99f69044.jpg"
                firebaseAuth.createUserWithEmailAndPassword(email,pasword).addOnCompleteListener {
                    if (it.isSuccessful){
                        firebaseAuth = FirebaseAuth.getInstance()
                        val user: FirebaseUser? = firebaseAuth.currentUser
                        val userId: String =user!!.uid
                                firebaseAuth.currentUser?.sendEmailVerification()
                                    ?.addOnCompleteListener { task ->
                                        if (task.isSuccessful){
                                            val firebaseUser = firebaseAuth.currentUser
                                            val email = firebaseUser!!.email
                                            Toast.makeText(this, "validate your email in $email account and login in",
                                                Toast.LENGTH_SHORT).show()
                                            startActivity(Intent(this, ActivityLogin::class.java))

                                        }
                                        else{
                                            Toast.makeText(this,"desoler une erreur c'est produit veuillez reesayer ulterieurement",
                                                Toast.LENGTH_LONG).show()
                                        }
                                    }
                                Toast.makeText(this,"connexion initialiser avec succes",
                                    Toast.LENGTH_LONG).show()
                            }
                            else{
                                Toast.makeText(applicationContext,"erreur lors de la sauvegarde de donner, Recommencer",
                                    Toast.LENGTH_LONG).show()
                            }

                        }
                }

                    }


                }

}