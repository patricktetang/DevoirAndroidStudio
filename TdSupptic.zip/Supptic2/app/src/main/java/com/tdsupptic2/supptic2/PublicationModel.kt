package com.tdsupptic2.supptic2

class PublicationModel (
    val extimatepic: String ="1 minutes de lecture",
    val heurepic: String ="2h",
    val id: String ="publication0",
    val namepic: String ="publicateur",
    var favor : Boolean = true,
    val profilpic: String ="http://graven.yt/plante.jpg",
    val publicationimage: String ="http://graven.yt/plante.jpg",
    val textpic: String ="Visite D'etude des etudiants de supptic a l'institut Superieur d'agriculture et de gestion d'obala L'institut Superieur d'agriculture at puis quoi encore",
)