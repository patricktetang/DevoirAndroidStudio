package com.tdsupptic2.supptic2

class UserModel (
    val profilpic: String ="https://i.pinimg.com/474x/10/8a/cb/108acb7518c10c08865f8ef74836108e.jpg",
    val useremail: String ="justinngah95@gmail.com",
    val userid: String ="id1",
    val username: String ="justin ngah",
    val userpasword: String ="12345789"
)